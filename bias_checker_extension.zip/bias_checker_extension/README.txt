BiasChecker Chrome Extension - Installation Instructions

1. Download the `BiasChecker-Extension.zip` file and extract it to a folder on your computer.
2. Open Google Chrome and go to `chrome://extensions/`.
3. Enable **Developer mode** by toggling the switch in the top-right corner.
4. Click **Load unpacked** and select the folder where you extracted the extension files.
5. The BiasChecker extension will now be installed and ready to use.